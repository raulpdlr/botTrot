//+------------------------------------------------------------------+
//|                                         EA Studio Expert Advisor |
//|                              Copyright 2016, Forex Software Ltd. |
//+------------------------------------------------------------------+
#property copyright "Forex Software Ltd."
#property version   "1.00"
#property strict

static input string StrategyProperties__ = "------------"; // ------ Expert Properties ------
static input double Entry_Amount = 0.01; // Entry lots
input int Stop_Loss   = 110; // Stop Loss (pips)
input int Take_Profit = 50; // Take Profit (pips)
static input string Ind0 = "------------";// ----- Moving Averages Crossover -----
input int Ind0Param0 = 25; // Fast MA period
input int Ind0Param1 = 42; // Slow MA period
static input string Ind1 = "------------";// ----- Alligator -----
input int Ind1Param0 = 37; // Jaws period
input int Ind1Param1 = 20; // Jaws shift
input int Ind1Param2 = 20; // Teeth period
input int Ind1Param3 = 4; // Teeth shift
input int Ind1Param4 = 4; // Lips period
input int Ind1Param5 = 3; // Lips shift
static input string Ind2 = "------------";// ----- Bollinger Bands -----
input int Ind2Param0 = 16; // Period
input double Ind2Param1 = 3.50; // Deviation

static input string ExpertSettings__ = "------------"; // ------ Expert Settings ------
static input int Magic_Number = 97099753; // Magic Number

#define TRADE_RETRY_COUNT 4
#define TRADE_RETRY_WAIT  100
#define OP_FLAT           -1
#define OP_BUY            ORDER_TYPE_BUY
#define OP_SELL           ORDER_TYPE_SELL

// Session time is set in seconds from 00:00
int sessionSundayOpen           = 0;     // 00:00
int sessionSundayClose          = 86400; // 24:00
int sessionMondayThursdayOpen   = 0;     // 00:00
int sessionMondayThursdayClose  = 86400; // 24:00
int sessionFridayOpen           = 0;     // 00:00
int sessionFridayClose          = 86400; // 24:00
bool sessionIgnoreSunday        = false;
bool sessionCloseAtSessionClose = false;
bool sessionCloseAtFridayClose  = false;

const double sigma=0.000001;

double posType   = OP_FLAT;
ulong  posTicket = 0;
double posLots   = 0;

datetime barTime;
double   pip;
double   stopLevel;
ENUM_ORDER_TYPE_FILLING orderFillingType;

int ind0handler;
int ind01handler;
int ind1handler;
int ind2handler;

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   barTime          = Time(0);
   stopLevel        = (int) SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   orderFillingType = IsFillingTypeAllowed(ORDER_FILLING_FOK) ? ORDER_FILLING_FOK : ORDER_FILLING_IOC;

   if(_Digits==4 || _Digits==5)
      pip=0.0001;
   else if(_Digits==2 || _Digits==3)
      pip=0.01;
   else if(_Digits==1)
      pip=0.1;
   else
      pip=1;

   ind0handler = iMA(NULL,0,Ind0Param0,0,MODE_SMA,PRICE_CLOSE);
   ind01handler= iMA(NULL,0,Ind0Param1,0,MODE_SMA,PRICE_CLOSE);
   ind1handler = iAlligator(NULL,0,Ind1Param0,Ind1Param1,Ind1Param2,Ind1Param3,Ind1Param4,Ind1Param5,MODE_SMMA,PRICE_MEDIAN);
   ind2handler = iBands(NULL,0,Ind2Param0,0,Ind2Param1,PRICE_CLOSE);

   return (INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTick()
  {
   datetime time=Time(0);
   if(time>barTime)
     {
      barTime=time;
      OnBar();
     }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnBar()
  {
   UpdatePosition();

   if(posType!=OP_FLAT && IsForceSessionClose())
     {
      ClosePosition();
      return;
     }

   if(IsOutOfSession())
     {
      return;
     }

   if(posType!=OP_FLAT)
     {
      ManageClose();
      UpdatePosition();
     }

   if(posType==OP_FLAT)
     {
      ManageOpen();
      UpdatePosition();
     }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void UpdatePosition()
  {
   posType   = OP_FLAT;
   posTicket = 0;
   posLots   = 0;
   int posTotal=PositionsTotal();
   for(int posIndex=0;posIndex<posTotal;posIndex++)
     {
      ulong ticket=PositionGetTicket(posIndex);
      if(PositionSelectByTicket(ticket) &&
         PositionGetString(POSITION_SYMBOL)==_Symbol &&
         PositionGetInteger(POSITION_MAGIC)==Magic_Number)
        {
         posType   = (int) PositionGetInteger(POSITION_TYPE);
         posLots   = NormalizeDouble(PositionGetDouble(POSITION_VOLUME), 2);
         posTicket = ticket;
         break;
        }
     }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ManageOpen()
  {
   double ind0buffer0[]; CopyBuffer(ind0handler, 0,1,2,ind0buffer0);
   double ind0buffer1[]; CopyBuffer(ind01handler,0,1,2,ind0buffer1);
   double ind0val1 = ind0buffer0[1];
   double ind0val2 = ind0buffer1[1];
   bool ind0long  = ind0val1 < ind0val2 - sigma;
   bool ind0short = ind0val1 > ind0val2 + sigma;

   double ind1buffer0[]; CopyBuffer(ind1handler,0,1,2,ind1buffer0);
   double ind1buffer1[]; CopyBuffer(ind1handler,1,1,2,ind1buffer1);
   double ind1buffer2[]; CopyBuffer(ind1handler,2,1,2,ind1buffer2);
   double ind1val1 = ind1buffer0[1];
   double ind1val2 = ind1buffer0[0];
   bool ind1long  = ind1val1 < ind1val2 - sigma;
   bool ind1short = ind1val1 > ind1val2 + sigma;

   bool canOpenLong  = ind0long && ind1long;
   bool canOpenShort = ind0short && ind1short;

   if(canOpenLong && canOpenShort)
      return;

   if(canOpenLong)
      OpenPosition(OP_BUY);
   else if(canOpenShort)
      OpenPosition(OP_SELL);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ManageClose()
  {
   double ind2buffer0[]; CopyBuffer(ind2handler,1,1,2,ind2buffer0);
   double ind2buffer1[]; CopyBuffer(ind2handler,2,1,2,ind2buffer1);
   double ind2upBand1 = ind2buffer0[1];
   double ind2dnBand1 = ind2buffer1[1];
   double ind2upBand2 = ind2buffer0[0];
   double ind2dnBand2 = ind2buffer1[0];
   bool ind2long  = Open(0) > ind2upBand1 + sigma && Open(1) < ind2upBand2 - sigma;
   bool ind2short = Open(0) < ind2dnBand1 - sigma && Open(1) > ind2dnBand2 + sigma;

   if(posType==OP_BUY && ind2long)
      ClosePosition();
   else if(posType==OP_SELL && ind2short)
      ClosePosition();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OpenPosition(int command)
  {
   double stopLoss   = GetStopLoss(command);
   double takeProfit = GetTakeProfit(command);
   ManageOrderSend(command,Entry_Amount,stopLoss,takeProfit,0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ClosePosition()
  {
   int command=posType==OP_BUY ? OP_SELL : OP_BUY;
   ManageOrderSend(command,posLots,0,0,posTicket);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ManageOrderSend(int command,double lots,double stopLoss,double takeProfit,ulong ticket)
  {
   for(int attempt=0; attempt<TRADE_RETRY_COUNT; attempt++)
     {
      if(IsTradeContextFree())
        {
         ResetLastError();
         MqlTick             tick;    SymbolInfoTick(_Symbol,tick);
         MqlTradeRequest     request; ZeroMemory(request);
         MqlTradeResult      result;  ZeroMemory(result);
         MqlTradeCheckResult check;   ZeroMemory(check);

         request.action       = TRADE_ACTION_DEAL;
         request.symbol       = _Symbol;
         request.volume       = lots;
         request.type         = command==OP_BUY ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
         request.price        = command==OP_BUY ? tick.ask : tick.bid;
         request.type_filling = orderFillingType;
         request.deviation    = 10;
         request.sl           = stopLoss;
         request.tp           = takeProfit;
         request.magic        = Magic_Number;
         request.position     = ticket;
         request.comment      = IntegerToString(Magic_Number);

         bool isOrderCheck = OrderCheck(request,check);
         bool isOrderSend  = false;

         if(isOrderCheck)
            isOrderSend=OrderSend(request,result);

         if(isOrderCheck && isOrderSend && result.retcode==TRADE_RETCODE_DONE)
            return;
        }
      Sleep(TRADE_RETRY_WAIT);
      Print("Order Send retry no: "+IntegerToString(attempt+2));
     }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double GetStopLoss(int command)
  {
   if(Stop_Loss==0)
      return (0);

   MqlTick tick; SymbolInfoTick(_Symbol,tick);
   double delta    = MathMax(pip*Stop_Loss, _Point*stopLevel);
   double price    = command==OP_BUY ? tick.bid : tick.ask;
   double stopLoss = command==OP_BUY ? price-delta : price+delta;
   return (NormalizeDouble(stopLoss, _Digits));
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double GetTakeProfit(int command)
  {
   if(Take_Profit==0)
      return (0);

   MqlTick tick; SymbolInfoTick(_Symbol,tick);
   double delta      = MathMax(pip*Take_Profit, _Point*stopLevel);
   double price      = command==OP_BUY ? tick.bid : tick.ask;
   double takeProfit = command==OP_BUY ? price+delta : price-delta;
   return (NormalizeDouble(takeProfit, _Digits));
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
datetime Time(int bar)
  {
   datetime buffer[]; ArrayResize(buffer,1);
   int result=CopyTime(_Symbol,_Period,bar,1,buffer);
   return (result==1 ? buffer[0] : 0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double Open(int bar)
  {
   double buffer[]; ArrayResize(buffer,1);
   int result=CopyOpen(_Symbol,_Period,bar,1,buffer);
   return (result==1 ? buffer[0] : 0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool IsTradeContextFree()
  {
   if(MQL5InfoInteger(MQL5_TRADE_ALLOWED))
      return (true);

   uint startWait=GetTickCount();
   Print("Trade context is busy! Waiting...");

   while(true)
     {
      if(IsStopped())
         return (false);

      uint diff=GetTickCount()-startWait;
      if(diff>30*1000)
        {
         Print("The waiting limit exceeded!");
         return (false);
        }

      if(MQL5InfoInteger(MQL5_TRADE_ALLOWED))
         return (true);
      Sleep(TRADE_RETRY_WAIT);
     }

   return (true);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool IsFillingTypeAllowed(int fillingType)
  {
   int filling=(int)SymbolInfoInteger(_Symbol,SYMBOL_FILLING_MODE);
   return (filling&fillingType==fillingType);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool IsOutOfSession()
  {
   MqlDateTime time0; TimeToStruct(Time(0),time0);
   int weekDay           = time0.day_of_week;
   long timeFromMidnight = Time(0)%86400;
   int periodLength      = PeriodSeconds(_Period);
   bool skipTrade        = false;

   if(weekDay==0)
     {
      if(sessionIgnoreSunday) return true;
      int lastBarFix=sessionCloseAtSessionClose ? periodLength : 0;
      skipTrade=timeFromMidnight<sessionSundayOpen || timeFromMidnight+lastBarFix>sessionSundayClose;
     }
   else if(weekDay<5)
     {
      int lastBarFix=sessionCloseAtSessionClose ? periodLength : 0;
      skipTrade=timeFromMidnight<sessionMondayThursdayOpen || timeFromMidnight+lastBarFix>sessionMondayThursdayClose;
     }
   else
     {
      int lastBarFix=sessionCloseAtFridayClose || sessionCloseAtSessionClose ? periodLength : 0;
      skipTrade=timeFromMidnight<sessionFridayOpen || timeFromMidnight+lastBarFix>sessionFridayClose;
     }

   return (skipTrade);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool IsForceSessionClose()
  {
   if(!sessionCloseAtFridayClose && !sessionCloseAtSessionClose)
      return (false);

   MqlDateTime time0; TimeToStruct(Time(0),time0);
   int weekDay           = time0.day_of_week;
   long timeFromMidnight = Time(0)%86400;
   int periodLength      = PeriodSeconds(_Period);
   int lastBarFix        = sessionCloseAtSessionClose ? periodLength : 0;

   bool forceExit=false;
   if(weekDay==0)
     {
      forceExit=timeFromMidnight+lastBarFix>sessionSundayClose;
     }
   else if(weekDay<5)
     {
      forceExit=timeFromMidnight+lastBarFix>sessionMondayThursdayClose;
     }
   else
     {
      int fridayBarFix=sessionCloseAtFridayClose || sessionCloseAtSessionClose ? periodLength : 0;
      forceExit=timeFromMidnight+fridayBarFix>sessionFridayClose;
     }

   return (forceExit);
  }
//+------------------------------------------------------------------+
/*STRATEGY MARKET MetaTrader-Demo; EURUSD; M30 */
/*STRATEGY CODE {"openFilters":[{"listIndexes":[3,0,0,0,0],"numValues":[25,42,0,0,0,0],"name":"Moving Averages Crossover"},{"listIndexes":[5,3,4,0,0],"numValues":[37,20,20,4,4,3],"name":"Alligator"}],"closeFilters":[{"listIndexes":[3,3,0,0,0],"numValues":[16,3.5,0,0,0,0],"name":"Bollinger Bands"}],"properties":{"entryLots":0.01,"stopLoss":110,"takeProfit":50,"useStopLoss":true,"useTakeProfit":true}} */
